(function(define) {
    var __define;
    typeof define === "function" && (__define = define, define = null);
    // modules are defined as an array
    // [ module function, map of requires ]
    //
    // map of requires is short require name -> numeric require
    //
    // anything defined in a previous bundle is accessed via the
    // orig method which is the require for previous bundles
    (function(modules, entry, mainEntry, parcelRequireName, globalName) {
        /* eslint-disable no-undef */ var globalObject = typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : {};
        /* eslint-enable no-undef */ // Save the require from previous bundle to this closure if any
        var previousRequire = typeof globalObject[parcelRequireName] === 'function' && globalObject[parcelRequireName];
        var cache = previousRequire.cache || {};
        // Do not use `require` to prevent Webpack from trying to bundle this call
        var nodeRequire = typeof module !== 'undefined' && typeof module.require === 'function' && module.require.bind(module);
        function newRequire(name, jumped) {
            if (!cache[name]) {
                if (!modules[name]) {
                    // if we cannot find the module within our internal map or
                    // cache jump to the current global require ie. the last bundle
                    // that was added to the page.
                    var currentRequire = typeof globalObject[parcelRequireName] === 'function' && globalObject[parcelRequireName];
                    if (!jumped && currentRequire) {
                        return currentRequire(name, true);
                    }
                    // If there are other bundles on this page the require from the
                    // previous one is saved to 'previousRequire'. Repeat this as
                    // many times as there are bundles until the module is found or
                    // we exhaust the require chain.
                    if (previousRequire) {
                        return previousRequire(name, true);
                    }
                    // Try the node require function if it exists.
                    if (nodeRequire && typeof name === 'string') {
                        return nodeRequire(name);
                    }
                    var err = new Error("Cannot find module '" + name + "'");
                    err.code = 'MODULE_NOT_FOUND';
                    throw err;
                }
                localRequire.resolve = resolve;
                localRequire.cache = {};
                var module1 = cache[name] = new newRequire.Module(name);
                modules[name][0].call(module1.exports, localRequire, module1, module1.exports, this);
            }
            return cache[name].exports;
            function localRequire(x) {
                var res = localRequire.resolve(x);
                return res === false ? {} : newRequire(res);
            }
            function resolve(x) {
                var id = modules[name][1][x];
                return id != null ? id : x;
            }
        }
        function Module(moduleName) {
            this.id = moduleName;
            this.bundle = newRequire;
            this.exports = {};
        }
        newRequire.isParcelRequire = true;
        newRequire.Module = Module;
        newRequire.modules = modules;
        newRequire.cache = cache;
        newRequire.parent = previousRequire;
        newRequire.register = function(id, exports1) {
            modules[id] = [
                function(require, module1) {
                    module1.exports = exports1;
                },
                {}
            ];
        };
        Object.defineProperty(newRequire, 'root', {
            get: function() {
                return globalObject[parcelRequireName];
            }
        });
        globalObject[parcelRequireName] = newRequire;
        for(var i = 0; i < entry.length; i++){
            newRequire(entry[i]);
        }
        if (mainEntry) {
            // Expose entry point to Node, AMD or browser globals
            // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
            var mainExports = newRequire(mainEntry);
            // CommonJS
            if (typeof exports === 'object' && typeof module !== 'undefined') {
                module.exports = mainExports;
            // RequireJS
            } else if (typeof define === 'function' && define.amd) {
                define(function() {
                    return mainExports;
                });
            // <script>
            } else if (globalName) {
                this[globalName] = mainExports;
            }
        }
    })({
        "kgW6q": [
            function(require, module1, exports1) {
                var _index = require("../../../src/background/index");
            },
            {
                "../../../src/background/index": "iqY5N"
            }
        ],
        "iqY5N": [
            function(require, module1, exports1) {
                // background service worker\uff1a\u6d88\u606f\u8def\u7531 + \u53d1\u5e03\u6267\u884c
                var _platforms = require("~sync/platforms");
                var _syndication = require("./syndication");
                let currentSyncData = null;
                let currentGroupId;
                let currentPublishPopup = null;
                // ---------- HTML \u6e32\u67d3\u5f15\u64ce\uff1a\u6269\u5c55\u6e32\u67d3\u7a97\u53e3\u7ba1\u7406 ----------
                // \u6e32\u67d3\u7a97\u53e3\u662f\u4e00\u4e2a\u5c0f\u7684\u6269\u5c55\u9875\u9762\uff08\u771f\u5b9e\u6e32\u67d3\u5668\u73af\u5883\uff0crAF/\u5e03\u5c40/\u5b57\u4f53\u90fd\u6b63\u5e38\uff09\uff0c
                // \u9996\u6b21\u4f7f\u7528 HTML \u5f15\u64ce\u65f6\u521b\u5efa\u4e00\u6b21\u5e76\u4fdd\u6d3b\uff1b\u88ab\u7528\u6237\u5173\u95ed\u540e\u4f1a\u81ea\u52a8\u91cd\u5efa\u3002
                let renderWindowId = null;
                async function ensureRenderWindow() {
                    if (renderWindowId !== null) try {
                        await chrome.windows.get(renderWindowId);
                        return;
                    } catch  {
                        renderWindowId = null // \u5df2\u88ab\u5173\u95ed\uff0c\u91cd\u5efa
                        ;
                    }
                    const win = await chrome.windows.create({
                        url: chrome.runtime.getURL("tabs/card-render.html"),
                        type: "popup",
                        width: 240,
                        height: 100,
                        focused: false
                    });
                    if (win.id !== undefined) {
                        renderWindowId = win.id;
                        // \u5173\u95ed\u4e8b\u4ef6\u91cc\u6e05\u7406\u8bb0\u5f55\uff0c\u4e0b\u6b21\u8bf7\u6c42\u81ea\u52a8\u91cd\u5efa
                        chrome.windows.onRemoved.addListener(function onRemoved(windowId) {
                            if (windowId === renderWindowId) {
                                renderWindowId = null;
                                chrome.windows.onRemoved.removeListener(onRemoved);
                            }
                        });
                    }
                    // \u7b49\u9875\u9762\u811a\u672c\u5c31\u7eea
                    await new Promise((resolve)=>setTimeout(resolve, 500));
                }
                async function relayToRenderWindow(payload) {
                    const send = ()=>chrome.runtime.sendMessage({
                            action: "X_DIST_HTML_RENDER",
                            ...payload
                        });
                    try {
                        return await send();
                    } catch (first) {
                        const message = String(first);
                        if (message.includes("Receiving end") || message.includes("message channel closed") || message.includes("asynchronous response")) {
                            // \u6e32\u67d3\u7a97\u53e3\u521a\u521b\u5efa/\u88ab\u5173\u95ed/\u5361\u6b7b\uff1a\u91cd\u5efa\u540e\u518d\u8bd5\u4e00\u6b21
                            console.warn("[card-render] HTML \u6e32\u67d3\u7a97\u53e3\u65e0\u54cd\u5e94\uff0c\u91cd\u5efa\u540e\u91cd\u8bd5");
                            renderWindowId = null;
                            await ensureRenderWindow();
                            return await send();
                        }
                        throw first;
                    }
                }
                chrome.runtime.onMessage.addListener((request, _sender, sendResponse)=>{
                    if (request.action === "X_DIST_FETCH_TWEET_MEDIA") {
                        (0, _syndication.fetchTweetMedia)(String(request.tweetId)).then(sendResponse).catch((error)=>{
                            sendResponse({
                                ok: false,
                                error: String(error),
                                images: [],
                                video: null,
                                videoPoster: null
                            });
                        });
                        return true;
                    }
                    // \u4ee3\u6293\u56fe\u7247\u5e76\u8f6c data URL\uff08\u5206\u4eab\u5361\u7247\u7684\u5934\u50cf\u7528\uff0c\u907f\u5f00\u5185\u5bb9\u811a\u672c\u7684 CORS \u9650\u5236\uff09
                    if (request.action === "X_DIST_FETCH_IMAGE_DATA") {
                        (async ()=>{
                            try {
                                const response = await fetch(String(request.url), {
                                    credentials: "omit"
                                });
                                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                                const blob = await response.blob();
                                const dataUrl = await new Promise((resolve, reject)=>{
                                    const reader = new FileReader();
                                    reader.onloadend = ()=>resolve(reader.result);
                                    reader.onerror = ()=>reject(new Error("FileReader \u8bfb\u53d6\u5931\u8d25"));
                                    reader.readAsDataURL(blob);
                                });
                                sendResponse({
                                    ok: true,
                                    dataUrl
                                });
                            } catch (error) {
                                sendResponse({
                                    ok: false,
                                    error: String(error)
                                });
                            }
                        })();
                        return true;
                    }
                    // \u5206\u4eab\u5361\u7247\u6e32\u67d3\uff08HTML \u5f15\u64ce\uff09\uff1a\u8f6c\u53d1\u5230\u6269\u5c55\u6e32\u67d3\u7a97\u53e3\u6267\u884c
                    if (request.action === "X_DIST_RENDER_CARDS" && request.engine === "html") {
                        (async ()=>{
                            try {
                                await ensureRenderWindow();
                                const res = await relayToRenderWindow({
                                    input: request.input,
                                    config: request.config,
                                    page: request.page
                                });
                                sendResponse(res ?? {
                                    ok: false,
                                    error: "\u6e32\u67d3\u7a97\u53e3\u65e0\u54cd\u5e94"
                                });
                            } catch (error) {
                                console.error("[card-render] HTML \u6e32\u67d3\u94fe\u8def\u5931\u8d25", error);
                                sendResponse({
                                    ok: false,
                                    error: String(error)
                                });
                            }
                        })();
                        return true;
                    }
                    if (request.action === "X_DIST_OPEN_PUBLISH") {
                        currentSyncData = request.data;
                        (async ()=>{
                            // \u590d\u7528\u540c\u4e00\u4e2a\u53d1\u5e03\u8fdb\u5ea6\u5c0f\u7a97\uff0c\u907f\u514d\u91cd\u590d\u53d1\u5e03\u65f6\u5f00\u591a\u4e2a
                            if (currentPublishPopup?.id) try {
                                await chrome.windows.remove(currentPublishPopup.id);
                            } catch  {
                            // \u7a97\u53e3\u53ef\u80fd\u5df2\u88ab\u7528\u6237\u5173\u95ed
                            }
                            currentPublishPopup = await chrome.windows.create({
                                url: chrome.runtime.getURL("tabs/publish.html"),
                                type: "popup",
                                width: 460,
                                height: 560
                            });
                        })();
                        sendResponse({
                            status: "received"
                        });
                        return true;
                    }
                    if (request.action === "X_DIST_PUBLISH_REQUEST_SYNC_DATA") {
                        sendResponse({
                            syncData: currentSyncData
                        });
                        return true;
                    }
                    // \u4e00\u952e\u5173\u95ed\u672c\u6b21\u5206\u53d1\u7684\u6807\u7b7e\u7ec4\uff08\u53d1\u5e03\u5b8c\u6210\u540e\uff0c\u4ece\u8fdb\u5ea6\u5c0f\u7a97\u89e6\u53d1\uff09
                    if (request.action === "X_DIST_CLOSE_GROUP") {
                        (async ()=>{
                            try {
                                if (!currentGroupId) {
                                    sendResponse({
                                        closed: 0
                                    });
                                    return;
                                }
                                const groupTabs = await chrome.tabs.query({
                                    groupId: currentGroupId
                                });
                                const tabIds = groupTabs.map((t)=>t.id).filter(Boolean);
                                await chrome.tabs.remove(tabIds);
                                currentGroupId = undefined;
                                sendResponse({
                                    closed: tabIds.length
                                });
                            } catch (error) {
                                sendResponse({
                                    error: String(error)
                                });
                            }
                        })();
                        return true;
                    }
                    if (request.action === "X_DIST_PUBLISH_NOW") {
                        const data = request.data;
                        if (Array.isArray(data.platforms) && data.platforms.length > 0) (async ()=>{
                            try {
                                const { tabs, groupId } = await (0, _platforms.createTabsForPlatforms)(data);
                                currentGroupId = groupId;
                                if (currentPublishPopup?.id) await chrome.windows.update(currentPublishPopup.id, {
                                    focused: true
                                });
                                sendResponse({
                                    tabs,
                                    groupId
                                });
                            } catch (error) {
                                console.error("\u521b\u5efa\u6807\u7b7e\u9875\u6216\u5206\u7ec4\u65f6\u51fa\u9519:", error);
                                sendResponse({
                                    error: String(error)
                                });
                            }
                        })();
                        else sendResponse({
                            error: "\u672a\u9009\u62e9\u4efb\u4f55\u5e73\u53f0"
                        });
                        return true;
                    }
                    return false;
                });
            },
            {
                "~sync/platforms": "8ofCZ",
                "./syndication": "6Xcf0"
            }
        ],
        "8ofCZ": [
            function(require, module1, exports1) {
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                parcelHelpers.defineInteropFlag(exports1);
                parcelHelpers.export(exports1, "PLATFORMS", ()=>PLATFORMS);
                parcelHelpers.export(exports1, "getInfoByName", ()=>getInfoByName);
                parcelHelpers.export(exports1, "getPlatformEntry", ()=>getPlatformEntry);
                // \u6309\u53d1\u5e03\u6a21\u5f0f\uff08\u56fe\u6587/\u89c6\u9891\uff09\u89e3\u6790\u52fe\u9009\u5e73\u53f0\u5bf9\u5e94\u7684 PlatformInfo \u540d\u79f0
                parcelHelpers.export(exports1, "resolvePlatformNames", ()=>resolvePlatformNames);
                // \u4e3a\u6bcf\u4e2a\u52fe\u9009\u5e73\u53f0\u6253\u5f00\u53d1\u5e03\u9875\u5e76\u6ce8\u5165\u81ea\u52a8\u5316\u811a\u672c
                parcelHelpers.export(exports1, "createTabsForPlatforms", ()=>createTabsForPlatforms);
                var _douyinDynamic = require("./adapters/douyin-dynamic");
                var _douyinVideo = require("./adapters/douyin-video");
                var _rednoteDynamic = require("./adapters/rednote-dynamic");
                var _rednoteVideo = require("./adapters/rednote-video");
                var _okjikeDynamic = require("./adapters/okjike-dynamic");
                var _okjikeVideo = require("./adapters/okjike-video");
                const PLATFORMS = [
                    {
                        key: "douyin",
                        name: "\u6296\u97f3",
                        homeUrl: "https://creator.douyin.com",
                        dynamic: {
                            type: "DYNAMIC",
                            name: "DYNAMIC_DOUYIN",
                            platformKey: "douyin",
                            platformName: "\u6296\u97f3",
                            injectUrl: "https://creator.douyin.com/creator-micro/content/upload?default-tab=3",
                            injectFunction: (0, _douyinDynamic.DynamicDouyin)
                        },
                        video: {
                            type: "VIDEO",
                            name: "VIDEO_DOUYIN",
                            platformKey: "douyin",
                            platformName: "\u6296\u97f3",
                            injectUrl: "https://creator.douyin.com/creator-micro/content/upload",
                            injectFunction: (0, _douyinVideo.VideoDouyin)
                        }
                    },
                    {
                        key: "rednote",
                        name: "\u5c0f\u7ea2\u4e66",
                        homeUrl: "https://creator.xiaohongshu.com",
                        dynamic: {
                            type: "DYNAMIC",
                            name: "DYNAMIC_REDNOTE",
                            platformKey: "rednote",
                            platformName: "\u5c0f\u7ea2\u4e66",
                            injectUrl: "https://creator.xiaohongshu.com/publish/publish?target=image",
                            injectFunction: (0, _rednoteDynamic.DynamicRednote)
                        },
                        video: {
                            type: "VIDEO",
                            name: "VIDEO_REDNOTE",
                            platformKey: "rednote",
                            platformName: "\u5c0f\u7ea2\u4e66",
                            injectUrl: "https://creator.xiaohongshu.com/publish/publish?target=video",
                            injectFunction: (0, _rednoteVideo.VideoRednote)
                        }
                    },
                    {
                        key: "okjike",
                        name: "\u5373\u523b",
                        homeUrl: "https://web.okjike.com",
                        dynamic: {
                            type: "DYNAMIC",
                            name: "DYNAMIC_OKJIKE",
                            platformKey: "okjike",
                            platformName: "\u5373\u523b",
                            injectUrl: "https://web.okjike.com",
                            injectFunction: (0, _okjikeDynamic.DynamicOkjike)
                        },
                        video: {
                            type: "VIDEO",
                            name: "VIDEO_OKJIKE",
                            platformKey: "okjike",
                            platformName: "\u5373\u523b",
                            injectUrl: "https://web.okjike.com",
                            injectFunction: (0, _okjikeVideo.VideoOkjike)
                        }
                    }
                ];
                const infoMap = Object.fromEntries(PLATFORMS.flatMap((p)=>[
                        [
                            p.dynamic.name,
                            p.dynamic
                        ],
                        [
                            p.video.name,
                            p.video
                        ]
                    ]));
                function getInfoByName(name) {
                    return infoMap[name] ?? null;
                }
                function getPlatformEntry(key) {
                    return PLATFORMS.find((p)=>p.key === key);
                }
                function resolvePlatformNames(keys, mode) {
                    return keys.map((key)=>{
                        const entry = getPlatformEntry(key);
                        if (!entry) return null;
                        return mode === "VIDEO" ? entry.video.name : entry.dynamic.name;
                    }).filter((name)=>name !== null);
                }
                async function createTabsForPlatforms(data) {
                    const tabs = [];
                    let groupId;
                    for (const info of data.platforms){
                        const platformInfo = getInfoByName(info.name);
                        if (!platformInfo) continue;
                        const injectUrl = info.injectUrl || platformInfo.injectUrl;
                        const tab = await chrome.tabs.create({
                            url: injectUrl
                        });
                        // \u7b49\u5f85\u6807\u7b7e\u9875\u52a0\u8f7d\u5b8c\u6210\uff0815 \u79d2\u515c\u5e95\u8d85\u65f6\uff0c\u9632\u6b62\u76d1\u542c\u6ce8\u518c\u665a\u4e8e\u52a0\u8f7d\u5b8c\u6210\u800c\u5361\u6b7b\uff09
                        await new Promise((resolve)=>{
                            let done = false;
                            const finish = ()=>{
                                if (done) return;
                                done = true;
                                chrome.tabs.onUpdated.removeListener(listener);
                                clearTimeout(safety);
                                resolve();
                            };
                            const listener = (tabId, changeInfo)=>{
                                if (tabId === tab.id && changeInfo.status === "complete") finish();
                            };
                            const safety = setTimeout(finish, 15000);
                            chrome.tabs.onUpdated.addListener(listener);
                        });
                        // \u6ce8\u5165\u53d1\u5e03\u811a\u672c
                        await chrome.scripting.executeScript({
                            target: {
                                tabId: tab.id
                            },
                            func: platformInfo.injectFunction,
                            args: [
                                data
                            ]
                        });
                        await chrome.tabs.update(tab.id, {
                            active: true
                        });
                        // create \u65f6\u523b\u7684 tab \u5bf9\u8c61\u662f\u8fc7\u671f\u7684\uff08title \u4e3a\u7a7a\u3001\u771f\u5b9e url \u5728 pendingUrl\uff09\uff0c
                        // \u9875\u9762\u5c31\u7eea\u540e\u91cd\u65b0\u8bfb\u53d6\uff0c\u4fdd\u8bc1\u8fdb\u5ea6\u5c0f\u7a97\u80fd\u663e\u793a\u6807\u9898/\u5730\u5740
                        const freshTab = await chrome.tabs.get(tab.id);
                        tabs.push({
                            tab: freshTab,
                            platformInfo: info,
                            platformLabel: platformInfo.platformName
                        });
                        // \u6240\u6709\u53d1\u5e03\u6807\u7b7e\u9875\u5f52\u5165\u4e00\u4e2a\u5206\u7ec4
                        try {
                            if (!groupId) {
                                groupId = await chrome.tabs.group({
                                    tabIds: [
                                        tab.id
                                    ]
                                });
                                await chrome.tabGroups.update(groupId, {
                                    color: "blue",
                                    title: `X\u5206\u53d1-${new Date().toLocaleTimeString("zh-CN", {
                                        hour: "2-digit",
                                        minute: "2-digit"
                                    })}`
                                });
                            } else await chrome.tabs.group({
                                tabIds: [
                                    tab.id
                                ],
                                groupId
                            });
                        } catch (error) {
                            console.warn("\u6807\u7b7e\u9875\u5206\u7ec4\u5931\u8d25\uff08\u4e0d\u5f71\u54cd\u53d1\u5e03\uff09:", error);
                        }
                        // \u5e73\u53f0\u95f4\u9694 3 \u79d2\uff0c\u907f\u514d\u540c\u65f6\u6253\u5f00\u591a\u4e2a\u53d1\u5e03\u9875\u9020\u6210\u5361\u987f
                        await new Promise((resolve)=>setTimeout(resolve, 3000));
                    }
                    return {
                        tabs,
                        groupId
                    };
                }
            },
            {
                "./adapters/douyin-dynamic": "8nOQ7",
                "./adapters/douyin-video": "iMjwH",
                "./adapters/rednote-dynamic": "fjhWL",
                "./adapters/rednote-video": "k5GiJ",
                "./adapters/okjike-dynamic": "grN0h",
                "./adapters/okjike-video": "4kTd2",
                "@parcel/transformer-js/src/esmodule-helpers.js": "hbR2Q"
            }
        ],
        "8nOQ7": [
            function(require, module1, exports1) {
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                parcelHelpers.defineInteropFlag(exports1);
                // \u6296\u97f3\u56fe\u6587\u5e16\u53d1\u5e03\u9002\u914d\u5668
                // \u6ce8\u610f\uff1a\u6b64\u51fd\u6570\u4f1a\u7ecf chrome.scripting.executeScript({func}) \u5e8f\u5217\u5316\u540e\u5728
                // creator.douyin.com \u9875\u9762\u5185\u6267\u884c\uff0c\u5fc5\u987b\u81ea\u5305\u542b\uff0c\u4e0d\u80fd\u5f15\u7528\u5916\u90e8\u4f5c\u7528\u57df\u3002
                parcelHelpers.export(exports1, "DynamicDouyin", ()=>DynamicDouyin);
                async function DynamicDouyin(data) {
                    const { title, content, images, tags } = data.data;
                    // \u8f85\u52a9\u51fd\u6570\uff1a\u7b49\u5f85\u5143\u7d20\u51fa\u73b0
                    function waitForElement(selector, timeout = 10000) {
                        return new Promise((resolve, reject)=>{
                            const element = document.querySelector(selector);
                            if (element) {
                                resolve(element);
                                return;
                            }
                            const observer = new MutationObserver(()=>{
                                const element = document.querySelector(selector);
                                if (element) {
                                    resolve(element);
                                    observer.disconnect();
                                }
                            });
                            observer.observe(document.body, {
                                childList: true,
                                subtree: true
                            });
                            setTimeout(()=>{
                                observer.disconnect();
                                reject(new Error(`Element with selector "${selector}" not found within ${timeout}ms`));
                            }, timeout);
                        });
                    }
                    if (!images || images.length === 0) {
                        console.error("\u53d1\u5e03\u6296\u97f3\u56fe\u6587\u9700\u8981\u81f3\u5c11\u4e00\u5f20\u56fe\u7247");
                        return;
                    }
                    await waitForElement('input[type="file"]');
                    await new Promise((resolve)=>setTimeout(resolve, 1000));
                    const semiTabs = document.querySelector(".semi-tabs.semi-tabs-top");
                    if (!semiTabs || !semiTabs.previousElementSibling) {
                        console.error("\u672a\u627e\u5230 semitabs \u6216\u5176\u524d\u7f6e\u5143\u7d20");
                        return;
                    }
                    const tabsDiv = semiTabs.previousElementSibling.querySelectorAll("div");
                    const publishTab = Array.from(tabsDiv).find((e)=>e.textContent === "\u53d1\u5e03\u56fe\u6587");
                    if (!publishTab) {
                        console.error("\u672a\u627e\u5230\u300c\u53d1\u5e03\u56fe\u6587\u300dtab");
                        return;
                    }
                    publishTab.click();
                    await new Promise((resolve)=>setTimeout(resolve, 1000));
                    const fileInput = document.querySelector('input[accept="image/png,image/jpeg,image/jpg,image/bmp,image/webp,image/tif"]');
                    if (!fileInput) {
                        console.error("\u672a\u627e\u5230\u56fe\u7247\u4e0a\u4f20 input");
                        return;
                    }
                    const dataTransfer = new DataTransfer();
                    for (const fileInfo of images){
                        const response = await fetch(fileInfo.url);
                        const blob = await response.blob();
                        const file = new File([
                            blob
                        ], fileInfo.name, {
                            type: fileInfo.type
                        });
                        dataTransfer.items.add(file);
                    }
                    fileInput.files = dataTransfer.files;
                    fileInput.dispatchEvent(new Event("change", {
                        bubbles: true
                    }));
                    fileInput.dispatchEvent(new Event("input", {
                        bubbles: true
                    }));
                    await waitForElement('input[placeholder="\u6dfb\u52a0\u4f5c\u54c1\u6807\u9898"]');
                    const titleInput = document.querySelector('input[placeholder="\u6dfb\u52a0\u4f5c\u54c1\u6807\u9898"]');
                    if (titleInput) {
                        titleInput.value = title || "";
                        titleInput.dispatchEvent(new Event("input", {
                            bubbles: true
                        }));
                    }
                    const contentEditor = document.querySelector('div.zone-container.editor-kit-container.editor.editor-comp-publish[contenteditable="true"]');
                    if (contentEditor) {
                        contentEditor.focus();
                        const pasteEvent = new ClipboardEvent("paste", {
                            bubbles: true,
                            cancelable: true,
                            clipboardData: new DataTransfer()
                        });
                        pasteEvent.clipboardData.setData("text/plain", content || "");
                        contentEditor.dispatchEvent(pasteEvent);
                        // \u6296\u97f3\u8bdd\u9898\u9650\u5236 4 \u4e2a\uff0c\u4ee5 #tag \u65b9\u5f0f\u8ffd\u52a0\u5230\u672b\u5c3e
                        if (tags?.length) for (const tag of tags.slice(0, 4)){
                            contentEditor.focus();
                            const tagPaste = new ClipboardEvent("paste", {
                                bubbles: true,
                                cancelable: true,
                                clipboardData: new DataTransfer()
                            });
                            tagPaste.clipboardData?.setData("text/plain", ` #${tag}`);
                            contentEditor.dispatchEvent(tagPaste);
                            await new Promise((resolve)=>setTimeout(resolve, 600));
                        }
                    }
                    await new Promise((resolve)=>setTimeout(resolve, 5000));
                    if (data.isAutoPublish) {
                        const buttons = document.querySelectorAll("button");
                        const publishButton = Array.from(buttons).find((e)=>e.textContent === "\u53d1\u5e03");
                        if (publishButton) {
                            publishButton.click();
                            await new Promise((resolve)=>setTimeout(resolve, 10000));
                            window.location.href = "https://creator.douyin.com/creator-micro/content/manage";
                        } else console.error("\u672a\u627e\u5230\u300c\u53d1\u5e03\u300d\u6309\u94ae");
                    }
                }
            },
            {
                "@parcel/transformer-js/src/esmodule-helpers.js": "hbR2Q"
            }
        ],
        "hbR2Q": [
            function(require, module1, exports1) {
                exports1.interopDefault = function(a) {
                    return a && a.__esModule ? a : {
                        default: a
                    };
                };
                exports1.defineInteropFlag = function(a) {
                    Object.defineProperty(a, "__esModule", {
                        value: true
                    });
                };
                exports1.exportAll = function(source, dest) {
                    Object.keys(source).forEach(function(key) {
                        if (key === "default" || key === "__esModule" || dest.hasOwnProperty(key)) return;
                        Object.defineProperty(dest, key, {
                            enumerable: true,
                            get: function() {
                                return source[key];
                            }
                        });
                    });
                    return dest;
                };
                exports1.export = function(dest, destName, get) {
                    Object.defineProperty(dest, destName, {
                        enumerable: true,
                        get: get
                    });
                };
            },
            {}
        ],
        "iMjwH": [
            function(require, module1, exports1) {
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                parcelHelpers.defineInteropFlag(exports1);
                // \u6296\u97f3\u89c6\u9891\u5e16\u53d1\u5e03\u9002\u914d\u5668
                // \u6b64\u51fd\u6570\u5728 creator.douyin.com \u9875\u9762\u5185\u6267\u884c\uff0c\u5fc5\u987b\u81ea\u5305\u542b\u3002
                parcelHelpers.export(exports1, "VideoDouyin", ()=>VideoDouyin);
                async function VideoDouyin(data) {
                    function waitForElement(selector, timeout = 10000) {
                        return new Promise((resolve, reject)=>{
                            const element = document.querySelector(selector);
                            if (element) {
                                resolve(element);
                                return;
                            }
                            const observer = new MutationObserver(()=>{
                                const element = document.querySelector(selector);
                                if (element) {
                                    resolve(element);
                                    observer.disconnect();
                                }
                            });
                            observer.observe(document.body, {
                                childList: true,
                                subtree: true
                            });
                            setTimeout(()=>{
                                observer.disconnect();
                                reject(new Error(`Element with selector "${selector}" not found within ${timeout}ms`));
                            }, timeout);
                        });
                    }
                    async function uploadVideo(file) {
                        const fileInput = await waitForElement("input[type=file]");
                        const dataTransfer = new DataTransfer();
                        dataTransfer.items.add(file);
                        fileInput.files = dataTransfer.files;
                        fileInput.dispatchEvent(new Event("change", {
                            bubbles: true
                        }));
                        fileInput.dispatchEvent(new Event("input", {
                            bubbles: true
                        }));
                    }
                    try {
                        const { content, video, title, tags } = data.data;
                        if (video) {
                            const response = await fetch(video.url);
                            const blob = await response.blob();
                            const videoFile = new File([
                                blob
                            ], video.name, {
                                type: video.type
                            });
                            await uploadVideo(videoFile);
                        }
                        await new Promise((resolve)=>setTimeout(resolve, 1000));
                        // \u5904\u7406\u6807\u9898\u8f93\u5165
                        const titleInput = await waitForElement('input[placeholder*="\u4f5c\u54c1\u6807\u9898"]');
                        if (titleInput) {
                            titleInput.value = title || content.slice(0, 20);
                            titleInput.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                        }
                        // \u586b\u5199\u5185\u5bb9\u548c\u6807\u7b7e
                        const contentEditor = await waitForElement('div.zone-container.editor-kit-container.editor.editor-comp-publish[contenteditable="true"]');
                        if (contentEditor) {
                            contentEditor.focus();
                            const contentPasteEvent = new ClipboardEvent("paste", {
                                bubbles: true,
                                cancelable: true,
                                clipboardData: new DataTransfer()
                            });
                            contentPasteEvent.clipboardData.setData("text/plain", `${content} `);
                            contentEditor.dispatchEvent(contentPasteEvent);
                            if (tags && tags.length > 0) for (const tag of tags.slice(0, 5)){
                                contentEditor.focus();
                                const pasteEvent = new ClipboardEvent("paste", {
                                    bubbles: true,
                                    cancelable: true,
                                    clipboardData: new DataTransfer()
                                });
                                pasteEvent.clipboardData.setData("text/plain", ` #${tag}`);
                                contentEditor.dispatchEvent(pasteEvent);
                                await new Promise((resolve)=>setTimeout(resolve, 1000));
                            }
                        }
                        if (data.isAutoPublish === true) {
                            await new Promise((resolve)=>setTimeout(resolve, 3000));
                            const buttons = document.querySelectorAll("button");
                            const publishButton = Array.from(buttons).find((button)=>button.textContent === "\u53d1\u5e03");
                            if (publishButton) publishButton.click();
                            else console.error('\u672a\u627e\u5230"\u53d1\u5e03"\u6309\u94ae');
                        }
                    } catch (error) {
                        console.error("\u6296\u97f3\u89c6\u9891\u53d1\u5e03\u8fc7\u7a0b\u4e2d\u51fa\u9519:", error);
                    }
                }
            },
            {
                "@parcel/transformer-js/src/esmodule-helpers.js": "hbR2Q"
            }
        ],
        "fjhWL": [
            function(require, module1, exports1) {
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                parcelHelpers.defineInteropFlag(exports1);
                // \u5c0f\u7ea2\u4e66\u56fe\u6587\u5e16\u53d1\u5e03\u9002\u914d\u5668
                // \u6b64\u51fd\u6570\u5728 creator.xiaohongshu.com \u9875\u9762\u5185\u6267\u884c\uff0c\u5fc5\u987b\u81ea\u5305\u542b\u3002
                parcelHelpers.export(exports1, "DynamicRednote", ()=>DynamicRednote);
                async function DynamicRednote(data) {
                    const { title, content, images, tags } = data.data;
                    // \u8f85\u52a9\u51fd\u6570\uff1a\u7b49\u5f85\u5143\u7d20\u51fa\u73b0
                    function waitForElement(selector, timeout = 10000) {
                        return new Promise((resolve, reject)=>{
                            const element = document.querySelector(selector);
                            if (element) {
                                resolve(element);
                                return;
                            }
                            const observer = new MutationObserver(()=>{
                                const element = document.querySelector(selector);
                                if (element) {
                                    resolve(element);
                                    observer.disconnect();
                                }
                            });
                            observer.observe(document.body, {
                                childList: true,
                                subtree: true
                            });
                            setTimeout(()=>{
                                observer.disconnect();
                                reject(new Error(`Element with selector "${selector}" not found within ${timeout}ms`));
                            }, timeout);
                        });
                    }
                    // \u8f85\u52a9\u51fd\u6570\uff1a\u4e0a\u4f20\u6587\u4ef6
                    async function uploadImages() {
                        const fileInput = await waitForElement('input[type="file"]');
                        if (!fileInput) {
                            console.error("\u672a\u627e\u5230\u6587\u4ef6\u8f93\u5165\u5143\u7d20");
                            return;
                        }
                        const dataTransfer = new DataTransfer();
                        for (const fileInfo of images)try {
                            const response = await fetch(fileInfo.url);
                            if (!response.ok) throw new Error(`HTTP \u9519\u8bef! \u72b6\u6001: ${response.status}`);
                            const blob = await response.blob();
                            const file = new File([
                                blob
                            ], fileInfo.name, {
                                type: fileInfo.type
                            });
                            dataTransfer.items.add(file);
                        } catch (error) {
                            console.error(`\u4e0a\u4f20\u56fe\u7247 ${fileInfo.url} \u5931\u8d25:`, error);
                        }
                        if (dataTransfer.files.length > 0) {
                            fileInput.files = dataTransfer.files;
                            fileInput.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                            await new Promise((resolve)=>setTimeout(resolve, 2000));
                        } else console.error("\u6ca1\u6709\u6210\u529f\u6dfb\u52a0\u4efb\u4f55\u6587\u4ef6");
                    }
                    if (images && images.length > 0) {
                        // \u7b49\u5f85\u9875\u9762\u52a0\u8f7d
                        await waitForElement('span[class="title"]');
                        await new Promise((resolve)=>setTimeout(resolve, 1000));
                        // \u70b9\u51fb\u4e0a\u4f20\u56fe\u6587\u6309\u94ae
                        const uploadButtons = document.querySelectorAll('span[class="title"]');
                        const uploadButton = Array.from(uploadButtons).find((element)=>element.textContent?.includes("\u4e0a\u4f20\u56fe\u6587"));
                        if (!uploadButton) {
                            console.error("\u672a\u627e\u5230\u4e0a\u4f20\u56fe\u6587\u6309\u94ae");
                            return;
                        }
                        uploadButton.click();
                        uploadButton.dispatchEvent(new Event("click", {
                            bubbles: true
                        }));
                        await new Promise((resolve)=>setTimeout(resolve, 1000));
                        // \u4e0a\u4f20\u6587\u4ef6
                        await uploadImages();
                        await new Promise((resolve)=>setTimeout(resolve, 5000));
                        // \u586b\u5199\u6807\u9898
                        const titleInput = await waitForElement('input[type="text"]');
                        if (titleInput) {
                            const titleText = title || content?.slice(0, 20) || "";
                            titleInput.value = titleText;
                            titleInput.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                        }
                        // \u586b\u5199\u5185\u5bb9
                        const contentEditor = await waitForElement('div[contenteditable="true"]');
                        if (contentEditor) {
                            contentEditor.focus();
                            const contentPasteEvent = new ClipboardEvent("paste", {
                                bubbles: true,
                                cancelable: true,
                                clipboardData: new DataTransfer()
                            });
                            const tagSuffix = tags?.length ? ` ${tags.map((t)=>`#${t}#`).join(" ")}` : "";
                            contentPasteEvent.clipboardData.setData("text/plain", `${content || ""}${tagSuffix}`);
                            contentEditor.dispatchEvent(contentPasteEvent);
                            await new Promise((resolve)=>setTimeout(resolve, 1000));
                            contentEditor.blur();
                        }
                        // \u81ea\u52a8\u53d1\u5e03
                        if (data.isAutoPublish) {
                            await new Promise((resolve)=>setTimeout(resolve, 2000));
                            const buttons = document.querySelectorAll("button");
                            const publishButton = Array.from(buttons).find((button)=>button.textContent?.includes("\u53d1\u5e03"));
                            if (publishButton) {
                                // \u7b49\u5f85\u6309\u94ae\u53ef\u7528
                                let attempts = 0;
                                while(publishButton.getAttribute("aria-disabled") === "true" && attempts < 120){
                                    await new Promise((resolve)=>setTimeout(resolve, 1000));
                                    attempts++;
                                }
                                if (publishButton.getAttribute("aria-disabled") !== "true") {
                                    publishButton.click();
                                    await new Promise((resolve)=>setTimeout(resolve, 10000));
                                    window.location.href = "https://creator.xiaohongshu.com/new/note-manager";
                                } else console.error("\u5c0f\u7ea2\u4e66\uff1a\u53d1\u5e03\u6309\u94ae\u4e0d\u53ef\u7528\uff0c\u8df3\u8fc7\u81ea\u52a8\u53d1\u5e03");
                            }
                        }
                    } else console.error("\u53d1\u5e03\u5c0f\u7ea2\u4e66\u56fe\u6587\u9700\u8981\u81f3\u5c11\u4e00\u5f20\u56fe\u7247");
                }
            },
            {
                "@parcel/transformer-js/src/esmodule-helpers.js": "hbR2Q"
            }
        ],
        "k5GiJ": [
            function(require, module1, exports1) {
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                parcelHelpers.defineInteropFlag(exports1);
                // \u5c0f\u7ea2\u4e66\u89c6\u9891\u5e16\u53d1\u5e03\u9002\u914d\u5668
                // \u6b64\u51fd\u6570\u5728 creator.xiaohongshu.com \u9875\u9762\u5185\u6267\u884c\uff0c\u5fc5\u987b\u81ea\u5305\u542b\u3002
                parcelHelpers.export(exports1, "VideoRednote", ()=>VideoRednote);
                async function VideoRednote(data) {
                    const { content, video, title, tags } = data.data;
                    // \u8f85\u52a9\u51fd\u6570\uff1a\u7b49\u5f85\u5143\u7d20\u51fa\u73b0
                    function waitForElement(selector, timeout = 10000) {
                        return new Promise((resolve, reject)=>{
                            const element = document.querySelector(selector);
                            if (element) {
                                resolve(element);
                                return;
                            }
                            const observer = new MutationObserver(()=>{
                                const element = document.querySelector(selector);
                                if (element) {
                                    resolve(element);
                                    observer.disconnect();
                                }
                            });
                            observer.observe(document.body, {
                                childList: true,
                                subtree: true
                            });
                            setTimeout(()=>{
                                observer.disconnect();
                                reject(new Error(`Element with selector "${selector}" not found within ${timeout}ms`));
                            }, timeout);
                        });
                    }
                    // \u8f85\u52a9\u51fd\u6570\uff1a\u4e0a\u4f20\u89c6\u9891
                    async function uploadVideo() {
                        const fileInput = await waitForElement('input[type="file"]');
                        if (!fileInput) {
                            console.error("\u672a\u627e\u5230\u6587\u4ef6\u8f93\u5165\u5143\u7d20");
                            return;
                        }
                        const dataTransfer = new DataTransfer();
                        if (video) try {
                            const response = await fetch(video.url);
                            if (!response.ok) throw new Error(`HTTP \u9519\u8bef! \u72b6\u6001: ${response.status}`);
                            const blob = await response.blob();
                            const file = new File([
                                blob
                            ], video.name, {
                                type: video.type
                            });
                            dataTransfer.items.add(file);
                        } catch (error) {
                            console.error(`\u4e0a\u4f20\u89c6\u9891 ${video.url} \u5931\u8d25:`, error);
                        }
                        if (dataTransfer.files.length > 0) {
                            fileInput.files = dataTransfer.files;
                            fileInput.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                            fileInput.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                            await new Promise((resolve)=>setTimeout(resolve, 2000));
                        }
                    }
                    // \u7b49\u5f85\u9875\u9762\u52a0\u8f7d
                    await waitForElement('span[class="title"]');
                    await new Promise((resolve)=>setTimeout(resolve, 1000));
                    // \u4e0a\u4f20\u89c6\u9891
                    await uploadVideo();
                    // \u7b49\u5f85\u6807\u9898\u8f93\u5165\u6846\u51fa\u73b0
                    await waitForElement('input[type="text"]');
                    await new Promise((resolve)=>setTimeout(resolve, 1000));
                    // \u586b\u5199\u6807\u9898
                    const titleInput = document.querySelector('input[type="text"]');
                    if (titleInput) {
                        const finalTitle = title?.slice(0, 20) || content?.slice(0, 20) || "";
                        titleInput.value = finalTitle;
                        titleInput.dispatchEvent(new Event("input", {
                            bubbles: true
                        }));
                    }
                    // \u586b\u5199\u5185\u5bb9\u548c\u6807\u7b7e
                    const editor = document.querySelector('div[contenteditable="true"]');
                    if (!editor) {
                        console.error("\u672a\u627e\u5230\u7f16\u8f91\u5668\u5143\u7d20");
                        return;
                    }
                    editor.focus();
                    const contentPasteEvent = new ClipboardEvent("paste", {
                        bubbles: true,
                        cancelable: true,
                        clipboardData: new DataTransfer()
                    });
                    contentPasteEvent.clipboardData.setData("text/plain", `${content}\n` || "");
                    editor.dispatchEvent(contentPasteEvent);
                    await new Promise((resolve)=>setTimeout(resolve, 1000));
                    editor.blur();
                    // \u6dfb\u52a0\u6807\u7b7e
                    if (tags && tags.length > 0) for (const tag of tags){
                        editor.focus();
                        const tagPasteEvent = new ClipboardEvent("paste", {
                            bubbles: true,
                            cancelable: true,
                            clipboardData: new DataTransfer()
                        });
                        tagPasteEvent.clipboardData.setData("text/plain", `#${tag}`);
                        editor.dispatchEvent(tagPasteEvent);
                        await new Promise((resolve)=>setTimeout(resolve, 2000));
                        // \u6a21\u62df\u56de\u8f66\u952e\u6309\u4e0b\u4ee5\u786e\u8ba4\u6807\u7b7e
                        const enterEvent = new KeyboardEvent("keydown", {
                            bubbles: true,
                            cancelable: true,
                            key: "Enter",
                            code: "Enter",
                            keyCode: 13,
                            which: 13
                        });
                        editor.dispatchEvent(enterEvent);
                        await new Promise((resolve)=>setTimeout(resolve, 2000));
                    }
                    if (data.isAutoPublish === true) {
                        // \u8f6e\u8be2\u671f\u95f4\u91cd\u65b0\u67e5\u8be2\u6309\u94ae\uff0c\u907f\u514d\u9875\u9762\u91cd\u6e32\u67d3\u540e\u6301\u6709\u5931\u6548\u8282\u70b9\uff1b\u89c6\u9891\u5904\u7406\u8f83\u6162\uff0c\u6700\u591a\u7ea6 60s
                        const findPublishButton = ()=>Array.from(document.querySelectorAll("button")).find((button)=>button.textContent?.includes("\u53d1\u5e03"));
                        let publishButton = findPublishButton();
                        for(let i = 0; i < 60; i++){
                            publishButton = findPublishButton();
                            if (publishButton && publishButton.getAttribute("aria-disabled") !== "true") break;
                            await new Promise((resolve)=>setTimeout(resolve, 1000));
                        }
                        if (publishButton && publishButton.getAttribute("aria-disabled") !== "true") {
                            publishButton.dispatchEvent(new Event("click", {
                                bubbles: true
                            }));
                            await new Promise((resolve)=>setTimeout(resolve, 10000));
                            window.location.href = "https://creator.xiaohongshu.com/new/note-manager";
                        } else console.error("\u5c0f\u7ea2\u4e66\uff1a\u53d1\u5e03\u6309\u94ae\u4ecd\u4e0d\u53ef\u7528\uff0c\u8df3\u8fc7\u81ea\u52a8\u53d1\u5e03");
                    }
                }
            },
            {
                "@parcel/transformer-js/src/esmodule-helpers.js": "hbR2Q"
            }
        ],
        "grN0h": [
            function(require, module1, exports1) {
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                parcelHelpers.defineInteropFlag(exports1);
                // \u5373\u523b\u56fe\u6587\u5e16\u53d1\u5e03\u9002\u914d\u5668
                // \u6b64\u51fd\u6570\u5728 web.okjike.com \u9875\u9762\u5185\u6267\u884c\uff0c\u5fc5\u987b\u81ea\u5305\u542b\u3002
                parcelHelpers.export(exports1, "DynamicOkjike", ()=>DynamicOkjike);
                async function DynamicOkjike(data) {
                    const { title, content, images, tags } = data.data;
                    const sleep = (ms)=>new Promise((resolve)=>setTimeout(resolve, ms));
                    // Wait for an element without throwing on timeout.
                    function waitForElement(selector, timeout = 10000) {
                        return new Promise((resolve)=>{
                            const element = document.querySelector(selector);
                            if (element) {
                                resolve(element);
                                return;
                            }
                            let timeoutId = undefined;
                            const observer = new MutationObserver(()=>{
                                const element = document.querySelector(selector);
                                if (element) {
                                    if (timeoutId) clearTimeout(timeoutId);
                                    observer.disconnect();
                                    resolve(element);
                                }
                            });
                            observer.observe(document.body, {
                                childList: true,
                                subtree: true
                            });
                            timeoutId = setTimeout(()=>{
                                observer.disconnect();
                                console.warn(`Element with selector "${selector}" not found within ${timeout}ms`);
                                resolve(null);
                            }, timeout);
                        });
                    }
                    function getUploadingStatus() {
                        return Array.from(document.querySelectorAll('div[role="status"]')).find((element)=>element.textContent?.includes("\u6b63\u5728\u4e0a\u4f20"));
                    }
                    async function waitForImageUploadToFinish(timeout = 60000, interval = 500) {
                        const deadline = Date.now() + timeout;
                        const firstCheckDeadline = Date.now() + 3000;
                        let sawUploading = false;
                        while(Date.now() < deadline){
                            const uploadingStatus = getUploadingStatus();
                            if (uploadingStatus) {
                                sawUploading = true;
                                await sleep(interval);
                                continue;
                            }
                            if (sawUploading || Date.now() >= firstCheckDeadline) return true;
                            await sleep(250);
                        }
                        return !getUploadingStatus();
                    }
                    function getUploadRoot(editor) {
                        const uploadRoot = editor.closest("form") || editor.closest('[role="dialog"]');
                        if (uploadRoot instanceof HTMLElement) return uploadRoot;
                        return editor.parentElement?.parentElement || editor.parentElement || editor;
                    }
                    function countAttachedImagePreviews(editor) {
                        const root = getUploadRoot(editor);
                        const previewImages = Array.from(root.querySelectorAll("img")).filter((image)=>Boolean(image.currentSrc || image.getAttribute("src")));
                        return new Set(previewImages).size;
                    }
                    async function createImageFiles(fileInfos) {
                        const imageFiles = [];
                        const limitedFileInfos = fileInfos.slice(0, 9);
                        if (fileInfos.length > limitedFileInfos.length) console.debug("Jike supports up to 9 images; skipping extra images");
                        for (const fileInfo of limitedFileInfos)try {
                            const response = await fetch(fileInfo.url);
                            if (!response.ok) {
                                console.error(`Failed to fetch image "${fileInfo.name}": ${response.status} ${response.statusText}`);
                                continue;
                            }
                            const blob = await response.blob();
                            const fileType = fileInfo.type || blob.type;
                            imageFiles.push(new File([
                                blob
                            ], fileInfo.name, {
                                type: fileType
                            }));
                        } catch (error) {
                            console.error("Failed to prepare Jike image:", error);
                        }
                        return imageFiles;
                    }
                    async function uploadFilesByPaste(editor, files) {
                        if (files.length === 0) return 0;
                        const attachedBefore = countAttachedImagePreviews(editor);
                        const dataTransfer = new DataTransfer();
                        for (const file of files)dataTransfer.items.add(file);
                        try {
                            editor.focus();
                            const imagePasteEvent = new ClipboardEvent("paste", {
                                bubbles: true,
                                cancelable: true,
                                clipboardData: dataTransfer
                            });
                            editor.dispatchEvent(imagePasteEvent);
                        } catch (error) {
                            console.error("Jike paste-based image upload failed:", error);
                            return 0;
                        }
                        const uploadFinished = await waitForImageUploadToFinish();
                        if (!uploadFinished) {
                            console.error("Jike image upload did not finish before timeout");
                            return 0;
                        }
                        const attachedAfter = countAttachedImagePreviews(editor);
                        const attachedCount = Math.max(0, attachedAfter - attachedBefore);
                        if (attachedCount > 0) return Math.min(attachedCount, files.length);
                        console.debug("No Jike paste upload evidence detected; trying file input fallback");
                        return 0;
                    }
                    async function uploadFilesByInput(editor, files) {
                        if (files.length === 0) return 0;
                        const fileInput = document.querySelector('input[type="file"]');
                        if (!fileInput) {
                            console.error("media requested but upload input not found");
                            return 0;
                        }
                        const attachedBefore = countAttachedImagePreviews(editor);
                        const dataTransfer = new DataTransfer();
                        for (const file of files)dataTransfer.items.add(file);
                        try {
                            fileInput.files = dataTransfer.files;
                            fileInput.dispatchEvent(new Event("change", {
                                bubbles: true
                            }));
                            fileInput.dispatchEvent(new Event("input", {
                                bubbles: true
                            }));
                        } catch (error) {
                            console.error("Jike file input image upload fallback failed:", error);
                            return 0;
                        }
                        const uploadFinished = await waitForImageUploadToFinish();
                        if (!uploadFinished) {
                            console.error("Jike image upload did not finish before timeout");
                            return 0;
                        }
                        const attachedAfter = countAttachedImagePreviews(editor);
                        const attachedCount = Math.max(0, attachedAfter - attachedBefore);
                        if (attachedCount > 0) return Math.min(attachedCount, files.length);
                        console.error("media requested but no attached image was detected");
                        return 0;
                    }
                    async function fillContent() {
                        const inputElement = await waitForElement('form div[contenteditable="true"], div[contenteditable="true"][role="textbox"]');
                        if (!inputElement) {
                            console.error("Jike editor not found");
                            return null;
                        }
                        const tagSuffix = tags?.length ? ` ${tags.map((t)=>`#${t}`).join(" ")}` : "";
                        const fullContent = title ? `${title}\n${content}${tagSuffix}` : `${content}${tagSuffix}`;
                        const pasteEvent = new ClipboardEvent("paste", {
                            bubbles: true,
                            cancelable: true,
                            clipboardData: new DataTransfer()
                        });
                        pasteEvent.clipboardData.setData("text/plain", fullContent);
                        inputElement.focus();
                        inputElement.dispatchEvent(pasteEvent);
                        return inputElement;
                    }
                    async function uploadFiles(editor) {
                        const files = await createImageFiles(images || []);
                        if (files.length === 0) return 0;
                        const pastedCount = await uploadFilesByPaste(editor, files);
                        if (pastedCount > 0) return pastedCount;
                        return await uploadFilesByInput(editor, files);
                    }
                    try {
                        const editor = await fillContent();
                        if (!editor) return;
                        const requestedImageCount = Math.min(images?.length ?? 0, 9);
                        let attachedImageCount = 0;
                        if (images && images.length > 0) attachedImageCount = await uploadFiles(editor);
                        if (data.isAutoPublish) {
                            if (requestedImageCount > 0 && attachedImageCount !== requestedImageCount) {
                                console.error(`only ${attachedImageCount} of ${requestedImageCount} requested images attached; skipping auto-publish to avoid an incomplete post`);
                                return;
                            }
                            if (requestedImageCount > 0) {
                                const uploadFinished = await waitForImageUploadToFinish();
                                if (!uploadFinished) {
                                    console.error("Jike image upload did not finish before auto-publish");
                                    return;
                                }
                            }
                            const buttons = document.querySelectorAll("button");
                            const publishButton = Array.from(buttons).find((button)=>button.textContent?.includes("\u53d1\u9001"));
                            if (publishButton) {
                                let attempts = 0;
                                while(publishButton.disabled && attempts < 10){
                                    await sleep(3000);
                                    attempts++;
                                }
                                if (publishButton.disabled) {
                                    console.error("\u53d1\u5e03\u6309\u94ae\u572810\u6b21\u5c1d\u8bd5\u540e\u4ecd\u88ab\u7981\u7528");
                                    return;
                                }
                                publishButton.click();
                            }
                        }
                    } catch (error) {
                        console.error("\u53d1\u5e03\u8fc7\u7a0b\u4e2d\u51fa\u9519:", error);
                    }
                }
            },
            {
                "@parcel/transformer-js/src/esmodule-helpers.js": "hbR2Q"
            }
        ],
        "4kTd2": [
            function(require, module1, exports1) {
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                parcelHelpers.defineInteropFlag(exports1);
                // \u5373\u523b\u89c6\u9891\u5e16\u53d1\u5e03\u9002\u914d\u5668
                // \u6b64\u51fd\u6570\u5728 web.okjike.com \u9875\u9762\u5185\u6267\u884c\uff0c\u5fc5\u987b\u81ea\u5305\u542b\u3002
                // \u5373\u523b\u7684 composer \u662f contenteditable \u5bcc\u6587\u672c\u7f16\u8f91\u5668\uff08\u6ca1\u6709 textarea\uff09\uff1a
                // \u6587\u6848\u7528\u6a21\u62df\u7c98\u8d34\u4e8b\u4ef6\u586b\u5165\uff0c\u89c6\u9891\u6587\u4ef6\u540c\u6837\u4ee5\u300c\u7c98\u8d34\u6587\u4ef6\u300d\u65b9\u5f0f\u4e0a\u4f20\uff08file input \u4ec5\u515c\u5e95\uff09\u3002
                // \u5904\u7406\u987a\u5e8f\uff1a\u5148\u6587\u672c\uff0c\u540e\u89c6\u9891\u3002
                parcelHelpers.export(exports1, "VideoOkjike", ()=>VideoOkjike);
                async function VideoOkjike(data) {
                    const { title, content, video } = data.data;
                    const sleep = (ms)=>new Promise((resolve)=>setTimeout(resolve, ms));
                    // \u7b49\u5f85\u5143\u7d20\uff0c\u8d85\u65f6\u4e0d\u629b\u9519\u8fd4\u56de null
                    function waitForElement(selector, timeout = 15000) {
                        return new Promise((resolve)=>{
                            const existing = document.querySelector(selector);
                            if (existing) {
                                resolve(existing);
                                return;
                            }
                            let timeoutId = undefined;
                            const observer = new MutationObserver(()=>{
                                const element = document.querySelector(selector);
                                if (element) {
                                    if (timeoutId) clearTimeout(timeoutId);
                                    observer.disconnect();
                                    resolve(element);
                                }
                            });
                            observer.observe(document.body, {
                                childList: true,
                                subtree: true
                            });
                            timeoutId = setTimeout(()=>{
                                observer.disconnect();
                                console.warn(`[X\u5206\u53d1] Element with selector "${selector}" not found within ${timeout}ms`);
                                resolve(null);
                            }, timeout);
                        });
                    }
                    function getUploadingStatus() {
                        return Array.from(document.querySelectorAll('div[role="status"]')).find((element)=>element.textContent?.includes("\u6b63\u5728\u4e0a\u4f20"));
                    }
                    async function waitForUploadToFinish(timeout = 120000, interval = 500) {
                        const deadline = Date.now() + timeout;
                        const firstCheckDeadline = Date.now() + 3000;
                        let sawUploading = false;
                        while(Date.now() < deadline){
                            const uploadingStatus = getUploadingStatus();
                            if (uploadingStatus) {
                                sawUploading = true;
                                await sleep(interval);
                                continue;
                            }
                            if (sawUploading || Date.now() >= firstCheckDeadline) return true;
                            await sleep(250);
                        }
                        return !getUploadingStatus();
                    }
                    // \u586b\u5199\u6587\u6848\uff1a\u7b49\u5f85\u7f16\u8f91\u5668 \u2192 \u6a21\u62df\u7c98\u8d34\u7eaf\u6587\u672c\uff08\u4e0e\u56fe\u6587\u7248\u540c\u6b3e\uff0c\u5df2\u9a8c\u8bc1\u53ef\u7528\uff09
                    async function fillContent() {
                        const editor = await waitForElement('form div[contenteditable="true"], div[contenteditable="true"][role="textbox"]');
                        if (!editor) {
                            console.error("[X\u5206\u53d1] \u5373\u523b\u7f16\u8f91\u5668\u672a\u627e\u5230");
                            return null;
                        }
                        const fullContent = title ? `${title}\n${content}` : content;
                        editor.focus();
                        const pasteEvent = new ClipboardEvent("paste", {
                            bubbles: true,
                            cancelable: true,
                            clipboardData: new DataTransfer()
                        });
                        pasteEvent.clipboardData.setData("text/plain", fullContent);
                        editor.dispatchEvent(pasteEvent);
                        await sleep(500);
                        return editor;
                    }
                    // \u4e0a\u4f20\u89c6\u9891\uff1a\u4f18\u5148\u300c\u5411\u7f16\u8f91\u5668\u7c98\u8d34\u89c6\u9891\u6587\u4ef6\u300d\uff0c\u5931\u8d25\u518d\u9000\u56de input[type=file]
                    async function uploadVideo(editor) {
                        if (!video) {
                            console.error("[X\u5206\u53d1] \u6ca1\u6709\u89c6\u9891\u6587\u4ef6");
                            return;
                        }
                        const dataTransfer = new DataTransfer();
                        try {
                            // video.url \u662f\u6269\u5c55\u53d1\u5e03\u9875\u751f\u6210\u7684 blob: URL\uff08\u5a92\u4f53\u5df2\u5728\u53d1\u5e03\u9875\u5b8c\u6210\u4e0b\u8f7d\uff09
                            const response = await fetch(video.url);
                            if (!response.ok) throw new Error(`HTTP \u9519\u8bef! \u72b6\u6001: ${response.status}`);
                            const blob = await response.blob();
                            const file = new File([
                                blob
                            ], video.name, {
                                type: video.type || "video/mp4"
                            });
                            dataTransfer.items.add(file);
                        } catch (error) {
                            console.error("[X\u5206\u53d1] \u8bfb\u53d6\u89c6\u9891\u5931\u8d25\uff08\u53d1\u5e03\u8fdb\u5ea6\u5c0f\u7a97\u88ab\u63d0\u524d\u5173\u95ed\u4f1a\u5bfc\u81f4 blob \u5931\u6548\uff09:", error);
                            return;
                        }
                        // \u8def\u5f84 1\uff1a\u5411\u7f16\u8f91\u5668\u7c98\u8d34\u89c6\u9891\u6587\u4ef6
                        try {
                            editor.focus();
                            const pasteEvent = new ClipboardEvent("paste", {
                                bubbles: true,
                                cancelable: true,
                                clipboardData: dataTransfer
                            });
                            editor.dispatchEvent(pasteEvent);
                            await waitForUploadToFinish();
                            // \u7f16\u8f91\u5668\u5185\u51fa\u73b0\u89c6\u9891\u9884\u89c8\u5373\u8ba4\u4e3a\u6210\u529f
                            const root = editor.closest("form") || editor.closest('[role="dialog"]') || editor.parentElement;
                            if (root && root.querySelector("video")) return;
                            console.warn("[X\u5206\u53d1] \u7c98\u8d34\u89c6\u9891\u672a\u5728\u7f16\u8f91\u5668\u4e2d\u51fa\u73b0\uff0c\u5c1d\u8bd5 file input \u515c\u5e95");
                        } catch (error) {
                            console.warn("[X\u5206\u53d1] \u7c98\u8d34\u89c6\u9891\u5931\u8d25\uff0c\u5c1d\u8bd5 file input \u515c\u5e95:", error);
                        }
                        // \u8def\u5f84 2\uff1afile input \u515c\u5e95\uff08\u4efb\u610f accept \u7684\u7b2c\u4e00\u4e2a\u6587\u4ef6\u8f93\u5165\uff09
                        const fileInput = await waitForElement('input[type="file"]', 10000);
                        if (!fileInput) {
                            console.error("[X\u5206\u53d1] \u672a\u627e\u5230\u5373\u523b\u7684\u6587\u4ef6\u8f93\u5165\u5143\u7d20");
                            return;
                        }
                        const inputTransfer = new DataTransfer();
                        try {
                            const response = await fetch(video.url);
                            const blob = await response.blob();
                            inputTransfer.items.add(new File([
                                blob
                            ], video.name, {
                                type: video.type || "video/mp4"
                            }));
                        } catch (error) {
                            console.error("[X\u5206\u53d1] file input \u515c\u5e95\u8bfb\u53d6\u89c6\u9891\u5931\u8d25:", error);
                            return;
                        }
                        fileInput.files = inputTransfer.files;
                        fileInput.dispatchEvent(new Event("change", {
                            bubbles: true
                        }));
                        fileInput.dispatchEvent(new Event("input", {
                            bubbles: true
                        }));
                        await waitForUploadToFinish();
                    }
                    // \u4e3b\u6d41\u7a0b\uff1a\u5148\u6587\u672c\uff0c\u540e\u89c6\u9891\uff1b\u5355\u6b65\u5931\u8d25\u4e0d\u963b\u65ad\u53e6\u4e00\u6b65
                    try {
                        const editor = await fillContent();
                        if (!editor) return;
                        try {
                            await uploadVideo(editor);
                        } catch (error) {
                            console.error("[X\u5206\u53d1] \u5373\u523b\u89c6\u9891\u4e0a\u4f20\u5931\u8d25:", error);
                        }
                        if (data.isAutoPublish) {
                            await sleep(3000);
                            const buttons = document.querySelectorAll("button");
                            const publishButton = Array.from(buttons).find((button)=>button.textContent?.includes("\u53d1\u5e03"));
                            if (publishButton) {
                                let attempts = 0;
                                while(publishButton.disabled && attempts < 10){
                                    await sleep(3000);
                                    attempts++;
                                }
                                if (publishButton.disabled) {
                                    console.error("\u53d1\u5e03\u6309\u94ae\u572810\u6b21\u5c1d\u8bd5\u540e\u4ecd\u88ab\u7981\u7528");
                                    return;
                                }
                                publishButton.click();
                            }
                        }
                    } catch (error) {
                        console.error("\u53d1\u5e03\u8fc7\u7a0b\u4e2d\u51fa\u9519:", error);
                    }
                }
            },
            {
                "@parcel/transformer-js/src/esmodule-helpers.js": "hbR2Q"
            }
        ],
        "6Xcf0": [
            function(require, module1, exports1) {
                // \u901a\u8fc7\u63a8\u7279\u516c\u5f00\u7684 syndication \u63a5\u53e3\u89e3\u6790\u63a8\u6587\u5a92\u4f53\uff08\u4e0e vercel/react-tweet \u540c\u6b3e\u5b9e\u73b0\uff09
                // \u8be5\u63a5\u53e3\u65e0\u9700\u767b\u5f55\uff1bservice worker \u6301\u6709 host_permissions\uff0c\u53ef\u8de8\u57df fetch
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                parcelHelpers.defineInteropFlag(exports1);
                parcelHelpers.export(exports1, "fetchTweetMedia", ()=>fetchTweetMedia);
                var _tweet = require("~extract/tweet");
                // react-tweet \u7684 token \u7b97\u6cd5\uff1a\u7531\u63a8\u6587 ID \u63a8\u5bfc
                // https://github.com/vercel/react-tweet/blob/main/packages/react-tweet/src/api/fetch-tweet.ts
                function getToken(id) {
                    return (Number(id) / 1e15 * Math.PI).toString(36).replace(/(0+|\.)/g, "");
                }
                const FEATURES = [
                    "tfw_timeline_list:",
                    "tfw_follower_count_sunset:true",
                    "tfw_tweet_edit_backend:on",
                    "tfw_refsrc_session:on",
                    "tfw_fosnr_soft_interventions_enabled:on",
                    "tfw_show_birdwatch_pivots_enabled:on",
                    "tfw_show_business_verified_badge:on",
                    "tfw_duplicate_scribes_to_settings:on",
                    "tfw_use_profile_image_shape_enabled:on",
                    "tfw_show_blue_verified_badge:on",
                    "tfw_legacy_timeline_sunset:true",
                    "tfw_show_gov_verified_badge:on",
                    "tfw_show_business_affiliate_badge:on",
                    "tfw_tweet_edit_frontend:on"
                ].join(";");
                async function fetchTweetMedia(tweetId) {
                    const url = new URL("https://cdn.syndication.twimg.com/tweet-result");
                    url.searchParams.set("id", tweetId);
                    url.searchParams.set("lang", "en");
                    url.searchParams.set("token", getToken(tweetId));
                    url.searchParams.set("features", FEATURES);
                    try {
                        const response = await fetch(url.toString(), {
                            credentials: "omit"
                        });
                        if (!response.ok) return {
                            ok: false,
                            error: `syndication \u63a5\u53e3\u8fd4\u56de ${response.status}`,
                            images: [],
                            video: null,
                            videoPoster: null
                        };
                        const data = await response.json();
                        const media = (0, _tweet.syndicationToMedia)(data.mediaDetails ?? []);
                        return {
                            ok: true,
                            ...media
                        };
                    } catch (error) {
                        return {
                            ok: false,
                            error: error instanceof Error ? error.message : String(error),
                            images: [],
                            video: null,
                            videoPoster: null
                        };
                    }
                }
            },
            {
                "~extract/tweet": "aKAWZ",
                "@parcel/transformer-js/src/esmodule-helpers.js": "hbR2Q"
            }
        ],
        "aKAWZ": [
            function(require, module1, exports1) {
                // \u4ece x.com \u9875\u9762 DOM \u4e2d\u63d0\u53d6\u63a8\u6587\u5185\u5bb9\uff08\u6587\u672c / \u56fe\u7247 / \u89c6\u9891\u68c0\u6d4b / \u63a8\u6587 ID\uff09
                var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
                parcelHelpers.defineInteropFlag(exports1);
                // pbs.twimg.com \u56fe\u7247 URL \u652f\u6301 name \u53c2\u6570\u63a7\u5236\u5c3a\u5bf8\uff08small/medium/large/orig\uff09
                parcelHelpers.export(exports1, "withImageSize", ()=>withImageSize);
                parcelHelpers.export(exports1, "extractTweet", ()=>extractTweet);
                // \u5c06 syndication mediaDetails \u8f6c\u4e3a\u9762\u677f\u5a92\u4f53\u9879\uff08\u5728 background \u4e0e\u5185\u5bb9\u811a\u672c\u4e2d\u5747\u53ef\u8c03\u7528\uff09
                parcelHelpers.export(exports1, "syndicationToMedia", ()=>syndicationToMedia);
                function withImageSize(url, name) {
                    try {
                        const u = new URL(url);
                        if (u.searchParams.has("name")) {
                            u.searchParams.set("name", name);
                            return u.toString();
                        }
                        return url;
                    } catch  {
                        return url;
                    }
                }
                function imageFileData(url) {
                    let name = "image.jpg";
                    let type = "image/jpeg";
                    try {
                        const u = new URL(url);
                        const id = u.pathname.split("/").pop() || "image";
                        const format = u.searchParams.get("format");
                        const ext = format || id.split(".").pop() || "jpg";
                        name = `${id.includes(".") ? id.split(".")[0] : id}.${ext}`;
                        type = ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg";
                    } catch  {
                    // ignore
                    }
                    return {
                        kind: "image",
                        url: withImageSize(url, "orig"),
                        thumbUrl: withImageSize(url, "small"),
                        name,
                        type
                    };
                }
                // \u4ece article DOM \u89e3\u6790\u63a8\u6587\u81ea\u8eab\uff08\u975e\u5f15\u7528\u63a8\u6587\uff09\u7684 status id
                function extractTweetId(article) {
                    const anchors = Array.from(article.querySelectorAll('a[href*="/status/"]'));
                    const pattern = /^\/[^/]+\/status\/(\d+)/;
                    // \u4f18\u5148\u53d6\u5f15\u7528\u63a8\u6587\u533a\u57df\u4e4b\u5916\u7684\u94fe\u63a5\uff08\u63a8\u6587\u81ea\u8eab\u7684\u65f6\u95f4\u6233\u94fe\u63a5\uff09
                    const outer = anchors.filter((a)=>!a.closest('div[data-testid="quoteTweet"]'));
                    for (const a of [
                        ...outer,
                        ...anchors
                    ]){
                        const m = a.getAttribute("href")?.match(pattern);
                        if (m) return m[1];
                    }
                    return null;
                }
                // \u4ece article DOM \u89e3\u6790\u4f5c\u8005\u663e\u793a\u540d / @handle\uff08\u7528\u4e8e\u5206\u4eab\u5361\u7247\uff09
                function extractAuthor(article) {
                    const userNameEl = article.querySelector('div[data-testid="User-Name"]');
                    if (!userNameEl) return {
                        authorName: "",
                        authorHandle: ""
                    };
                    const anchors = Array.from(userNameEl.querySelectorAll("a"));
                    let authorHandle = "";
                    for (const a of anchors){
                        const text = (a.innerText || "").trim();
                        if (text.startsWith("@") && !authorHandle) {
                            authorHandle = text;
                            break;
                        }
                    }
                    const nameAnchor = anchors.find((a)=>{
                        const href = a.getAttribute("href") || "";
                        const text = (a.innerText || "").trim();
                        return /^\/[^/]+$/.test(href) && text !== "" && !text.startsWith("@");
                    });
                    const authorName = nameAnchor ? nameAnchor.innerText.trim() : "";
                    return {
                        authorName,
                        authorHandle
                    };
                }
                // \u4ece\u63a8\u6587\u64cd\u4f5c\u680f\u6309\u94ae\uff08reply/retweet/like/bookmark\uff09\u63d0\u53d6\u683c\u5f0f\u5316\u7684\u4e92\u52a8\u6570
                function buttonCount(article, testid) {
                    const btn = article.querySelector(`button[data-testid="${testid}"]`);
                    if (!btn) return "";
                    const span = btn.querySelector("span");
                    const text = span?.innerText?.trim();
                    if (text) return text;
                    // \u56de\u590d\u6570\u4e3a 0 \u65f6\u6309\u94ae\u91cc\u6ca1\u6709 span\uff0c\u9000\u56de aria-label\uff08\u5982\u300c25 replies. Reply\u300d/\u300c25 \u56de\u590d\u300d\uff09
                    const label = btn.getAttribute("aria-label") ?? "";
                    const m = label.match(/\d[\d.,]*\s*[KMB]?/i);
                    return m ? m[0].trim() : "";
                }
                // \u6d4f\u89c8\u6570\u5728 analytics \u94fe\u63a5\u91cc\uff08\u5982\u300c14.4K Views\u300d/\u300c14.4K \u6b21\u67e5\u770b\u300d\uff09
                function extractViews(article) {
                    const link = article.querySelector('a[href$="/analytics"]');
                    if (!link) return "";
                    return (link.innerText || "").replace(/views?|\u6b21\u6d4f\u89c8|\u6b21\u67e5\u770b/gi, "").trim();
                }
                function extractTweet(article) {
                    // \u6587\u672c\uff1a\u666e\u901a\u63a8\u6587 + \u5f15\u7528\u63a8\u6587\u7684\u6587\u672c\u90fd\u5728 tweetText \u91cc\uff0c\u6309\u987a\u5e8f\u62fc\u63a5
                    const textNodes = article.querySelectorAll('div[data-testid="tweetText"]');
                    const text = Array.from(textNodes).map((n)=>n.innerText.trim()).filter(Boolean).join("\n\n");
                    // \u56fe\u7247\uff1atweetPhoto \u5185\u7684 img\uff0c\u8fc7\u6ee4\u51fa\u63a8\u7279\u56fe\u5e8a\u5730\u5740
                    const imgNodes = article.querySelectorAll('div[data-testid="tweetPhoto"] img');
                    const seen = new Set();
                    const media = [];
                    for (const img of imgNodes){
                        const src = img.currentSrc || img.src;
                        if (!src || !src.includes("pbs.twimg.com")) continue;
                        const origUrl = withImageSize(src, "orig");
                        if (seen.has(origUrl)) continue;
                        seen.add(origUrl);
                        media.push(imageFileData(src));
                    }
                    // \u89c6\u9891\u68c0\u6d4b\uff1aarticle \u5185\u5b58\u5728 video \u5143\u7d20\uff08src \u662f blob\uff0c\u771f\u5b9e\u5730\u5740\u9700\u8d70 syndication \u63a5\u53e3\uff09
                    const videoEl = article.querySelector("video");
                    const hasVideo = videoEl !== null;
                    const videoPoster = videoEl && videoEl.poster && videoEl.poster.includes("pbs.twimg.com") ? videoEl.poster : null;
                    const tweetId = extractTweetId(article);
                    // \u4f5c\u8005\u4fe1\u606f\uff08\u5206\u4eab\u5361\u7247\u7528\uff09
                    const { authorName, authorHandle } = extractAuthor(article);
                    const avatarEl = article.querySelector('div[data-testid="Tweet-User-Avatar"] img');
                    const avatarUrl = avatarEl?.src || null;
                    const verified = Boolean(article.querySelector('[data-testid="icon-verified"]'));
                    const datetime = article.querySelector("time")?.getAttribute("datetime");
                    const dateText = datetime ? new Date(datetime).toLocaleDateString("zh-CN", {
                        year: "numeric",
                        month: "long",
                        day: "numeric"
                    }) : "";
                    const stats = {
                        replies: buttonCount(article, "reply"),
                        retweets: buttonCount(article, "retweet"),
                        likes: buttonCount(article, "like"),
                        bookmarks: buttonCount(article, "bookmark"),
                        views: extractViews(article)
                    };
                    const tweetUrl = tweetId && authorHandle ? `https://x.com/${authorHandle.replace(/^@/, "")}/status/${tweetId}` : null;
                    return {
                        tweetId,
                        text,
                        media,
                        hasVideo,
                        videoPoster,
                        authorName,
                        authorHandle,
                        avatarUrl,
                        verified,
                        dateText,
                        stats,
                        tweetUrl
                    };
                }
                function syndicationToMedia(details) {
                    const images = [];
                    let video = null;
                    let videoPoster = null;
                    for (const detail of details ?? [])if (detail.type === "photo") {
                        const item = imageFileData(detail.media_url_https);
                        images.push(item);
                    } else {
                        // video / animated_gif\uff1a\u53d6\u7801\u7387\u6700\u9ad8\u7684 mp4 \u53d8\u4f53
                        const variants = detail.video_info?.variants ?? [];
                        const mp4s = variants.filter((v)=>v.content_type === "video/mp4" && v.url);
                        const best = mp4s.sort((a, b)=>(b.bitrate ?? 0) - (a.bitrate ?? 0))[0];
                        if (best) video = {
                            kind: "video",
                            url: best.url,
                            thumbUrl: detail.media_url_https,
                            name: `video-${detail.media_url_https.split("/").pop()?.split("?")[0] || "video"}.mp4`,
                            type: "video/mp4"
                        };
                        videoPoster = detail.media_url_https || null;
                    }
                    return {
                        images,
                        video,
                        videoPoster
                    };
                }
            },
            {
                "@parcel/transformer-js/src/esmodule-helpers.js": "hbR2Q"
            }
        ]
    }, [
        "kgW6q"
    ], "kgW6q", "parcelRequire3937");
    globalThis.define = __define;
})(globalThis.define);
